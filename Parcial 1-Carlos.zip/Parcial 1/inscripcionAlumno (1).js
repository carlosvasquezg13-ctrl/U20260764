import readline from "node:readline";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

let nombreEstudiante;
let codigoInsc;

console.log("--- Inscripcion ---");

rl.question("Ingresa el nombre completo del estudiante: ", (txtNombre) => {
  nombreEstudiante = txtNombre;

  rl.question("Ingresa el codigo de inscripcion (ej. ING-2026-0845): ", (txtCodigo) => {
    codigoInsc = txtCodigo;

    let estudianteUpper = nombreEstudiante.toUpperCase();
    let codigoUpper = codigoInsc.toUpperCase();
    
    let partes = codigoUpper.split("-");
    let sigla = partes[0];
    let anioTxt = partes[1];
    let numReg = partes[2];
    let anioNum = parseInt(anioTxt);

    let estado;
    if (anioNum === 2026) {
      estado = "INSCRIPCIÓN VÁLIDA";
    } else {
      estado = "INSCRIPCIÓN NO VÁLIDA";
    }

    console.log("\n------------------------------------------");
    console.log(" TICKET DE INSCRIPCIÓN ");
    console.log("------------------------------------------");
    console.log("Estudiante: " + estudianteUpper);
    console.log("Código: " + codigoUpper);
    console.log("------------------------------------------");
    console.log("Carrera: " + sigla);
    console.log("Año: " + anioNum);
    console.log("Registro: " + numReg);
    console.log("------------------------------------------");
    console.log("Estado: " + estado);
    console.log("------------------------------------------");

    rl.close();
  });
});