import readline from "node:readline";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

let alumno;
let equipo;
let hrs;
const TARIFA = 2.25;

console.log("--- Prestamo de Equipos ---");

rl.question("Ingresa el nombre del estudiante: ", (nom) => {
  alumno = nom;

  rl.question("Ingresa el nombre del equipo: ", (eq) => {
    equipo = eq;

    rl.question("Ingresa la cantidad de horas solicitadas: ", (cant) => {
      hrs = parseFloat(cant);

      let total = hrs * TARIFA;
      let equipoMayus = equipo.toUpperCase();

      let fecha = new Date();
      let anio = fecha.getFullYear();
      let mes = String(fecha.getMonth() + 1).padStart(2, "0");
      let dia = String(fecha.getDate()).padStart(2, "0");
      let hora = String(fecha.getHours()).padStart(2, "0");
      let minutos = String(fecha.getMinutes()).padStart(2, "0");
      let segundos = String(fecha.getSeconds()).padStart(2, "0");

      let fechaActual = `${dia}/${mes}/${anio}`;
      let horaActual = `${hora}:${minutos}:${segundos}`;

      let jornada;
      if (fecha.getHours() < 12) {
        jornada = "Préstamo registrado en jornada de mañana";
      } else {
        jornada = "Préstamo registrado en jornada de tarde";
      }

      console.log("\n--- RECIBO DE PRÉSTAMO ---");
      console.log("Estudiante: " + alumno);
      console.log("Equipo: " + equipoMayus);
      console.log("Horas solicitadas: " + hrs);
      console.log("Fecha actual: " + fechaActual);
      console.log("Hora actual: " + horaActual);
      console.log("Costo total: $" + total.toFixed(2));
      console.log(jornada);
      console.log("----------------------------");

      rl.close();
    });
  });
});