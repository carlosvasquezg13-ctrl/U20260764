import readline from "node:readline";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

let trabajador;
let elaborados;
let malos;

console.log("--- Produccion Diaria ---");

rl.question("Ingresa el nombre del empleado: ", (res1) => {
  trabajador = res1;

  rl.question("Ingresa la cantidad de productos elaborados: ", (res2) => {
    elaborados = parseFloat(res2);

    rl.question("Ingresa la cantidad de productos defectuosos: ", (res3) => {
      malos = parseFloat(res3);

      let correctos = elaborados - malos;
      let pct = (correctos / elaborados) * 100;
      let estadoProd;

      if (pct >= 95) {
        estadoProd = "Producción aceptada";
      } else {
        estadoProd = "Producción requiere revisión";
      }

      let trabajadorUpper = trabajador.toUpperCase();

      console.log("\n--- RESULTADO ---");
      console.log("Empleado: " + trabajadorUpper);
      console.log("Productos correctos: " + correctos);
      console.log("Porcentaje: " + pct.toFixed(2) + "%");
      console.log(estadoProd);
      console.log("------------------");

      rl.close();
    });
  });
});